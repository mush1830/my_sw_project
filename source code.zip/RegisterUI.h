#pragma once
#include <fstream>
#include "Register.h"

class RegisterUI {
private:
    std::ifstream& in;
    std::ofstream& out;
    Register registerControl;  // Control ��ü

public:
    RegisterUI(std::ifstream& input, std::ofstream& output);
    void SubmitRegisterInfo(const std::string& id, const std::string& pw, const std::string& phone);     // ����� �Է� Control�� ����

};
