#include <string>

class Member {
public:
    std::string id, pw, phone;

    Member(std::string id, std::string pw, std::string phone);
};
