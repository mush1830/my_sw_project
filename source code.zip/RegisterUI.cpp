#include "RegisterUI.h"

RegisterUI::RegisterUI(std::ifstream& input, std::ofstream& output)
    : in(input), out(output), registerControl(output) {} // registerControl�� Register ��ü


void RegisterUI::SubmitRegisterInfo(const std::string& id, const std::string& pw, const std::string& phone) {
    registerControl.GetRegisterInfo(id, pw, phone);  // control���� �ѱ�
}
