#include <fstream>
#include <string>
#include "RegisterUI.h"
#include "doTask.h"
#include <iostream>


extern std::ifstream in_fp;
extern std::ofstream out_fp;
using namespace std;

void doTask()
{

    int menu_level_1 = 0, menu_level_2 = 0;
    int is_program_exit = 0;

    RegisterUI registerUI(in_fp, out_fp); // registerUI ��ü����

    while (!is_program_exit)
    {

        in_fp >> menu_level_1 >> menu_level_2;

        switch (menu_level_1)
        {
        case 1:
            switch (menu_level_2)
            {
            case 1: // 1.1 ȸ������
            {
                std::string id, pw, phone;
                in_fp >> id >> pw >> phone;
                registerUI.SubmitRegisterInfo(id, pw, phone);

                out_fp << "1.1. ȸ������" << std::endl;
                out_fp << "> " << id << " " << pw << " " << phone << std::endl;

                break;
            }
            case 2:
                switch (menu_level_2)
                {
                case 1: // 2.1 �α���

                {
                    out_fp << "2.1 �α���" << std::endl;
                    break;
                }
                case 2: // 2.2 �α׾ƿ�
                {
                    out_fp << "2.2 �α׾ƿ�" << std::endl;
                    break;
                }
                case 3:
                    switch (menu_level_2)
                    {
                    case 1: // 3.1 ������ ���
                    {
                        out_fp << "3.1 ������ ���" << std::endl;
                        break;
                    }
                    case 4:
                        switch (menu_level_2)
                        {

                        case 1: // 4.1 ������ �뿩

                        {
                            out_fp << "4.1 ������ �뿩" << std::endl;
                            break;
                        }
                        case 5:
                            switch (menu_level_2)
                            {
                            case 1: //  5.1 ������ �뿩 ����Ʈ
                                out_fp << "5.1 ������ �뿩 ����Ʈ" << std::endl;
                                break;
                            }


                        case 6:
                            switch (menu_level_2)
                            {
                            case 1: //  6.1����
                                out_fp << "6.1 ����" << std::endl;
                                is_program_exit = 1;
                                break;
                            }
                            break;
                        }

                    }
                }
            }
        }
    }
}