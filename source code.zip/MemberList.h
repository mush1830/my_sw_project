#pragma once
#include <vector>
#include "Member.h"

class MemberList {
private:
    std::vector<Member> members;
    MemberList() {}  // private constructor

public:
    static MemberList& getInstance();
    void saveNewMember(const Member& member);
};
