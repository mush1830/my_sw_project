#pragma once
#include <string>
#include <fstream>

class Login {
private:
    std::ofstream& out;

public:
    Login(std::ofstream& output);
    void getLoginInfo(const std::string& id, const std::string& pw);
};
