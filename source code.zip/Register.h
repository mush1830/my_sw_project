#include <string>
#include <fstream>
#include "MemberList.h"

class Register {
private:
    std::ofstream& out;

public:
    Register(std::ofstream& output);
    void ShowRegisterInfo();
    void GetRegisterInfo(const std::string& id, const std::string& pw, const std::string& phone);
};
#pragma once
